# Changelog

All notable changes in this project is documented in this file. 

## Release [0.0.3]

### Added
- Parameter support.
- `disablePastDays` parameter.
- CHANGELOG file

## Release [0.0.2]

### Added
- Fixed [#5](https://github.com/chrisssycollins/vanilla-calendar/issues/5)

## Release [0.0.1]

### Added
- Initial release
